<?php
    include_once("database/conectarbanco.php");
    include_once("usuario/funcoes.php");
    session_start();
    date_default_timezone_set("America/Sao_Paulo");